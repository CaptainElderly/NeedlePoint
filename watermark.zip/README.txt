Support small artists

Usage
py watermark.py [image] [jpeg quality] [dither pattern]